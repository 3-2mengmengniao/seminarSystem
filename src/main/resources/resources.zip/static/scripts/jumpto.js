
//to 1vali_psw.html
function to_psw(){     
		window.location.href='1vali_psw.html';
	};

function to_security(){     
		window.location.href='1vali_psw.html';
	};